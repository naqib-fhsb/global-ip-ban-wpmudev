import '../scss/dashboard-upsell.scss';
// Shared UI.
import "@wpmudev/shared-ui/dist/js/_src/modal-dialog";
// Custom scripts.
import "./upsell/notice";
